﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRManagement
{

    /// <summary>
    /// Base class for employee
    /// </summary>
    abstract class Person
    {
        //properties
        public int Id { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }
        public string Designation { get; set; }
        public double BasicPay { get; set; }

        //Let derived class provide its own implementation based on business.
        public abstract double CalculateSalary();

    }


    /// <summary>
    /// Derived class Permanent
    /// </summary>
    class Permanent : Person
    {
        public override double CalculateSalary()
        {
            return 2.0 * BasicPay;
        }
    }


    /// <summary>
    /// Derived class Temporary
    /// </summary>
    class Temporary : Person
    {
        public override double CalculateSalary()
        {
            return 1.5 * BasicPay;
        }
    }
    class Program
    {
        public static Person[] employeeList = new Person[2];
        static void Main(string[] args) //Client
        {
            // Add new employee - Permanent
            Person emp1 = new Permanent();  //Runtime polymorphism
            emp1.Id = 100;
            emp1.Name = "Jose";
            emp1.Age = 33;
            emp1.Designation = "Technical Lead";
            emp1.BasicPay = 20000;

            //storing employee to in-memory location
            employeeList[0] = emp1;

            // Add another new employee -  Temporary
            Person emp2 = new Temporary();  //Runtime polymorphism
            emp2.Id = 101;
            emp2.Name = "Andrew";
            emp2.Age = 30;
            emp2.Designation = "Technical Support";
            emp2.BasicPay = 15000;

            //storing employee to in-memory location
            employeeList[1] = emp2;

            //Getting employee details
            foreach (Person item in employeeList)
            {
                Console.WriteLine("-----------------");
                Console.WriteLine("Employee Name = {0}, Salary = {1}", item.Name, item.CalculateSalary());
                
            }
            Console.ReadKey();
        }
    }
}
